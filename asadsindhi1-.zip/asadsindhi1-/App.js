import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, StatusBar, Alert, ActivityIndicator, Dimensions
} from 'react-native';

// ── THEME ──────────────────────────────────────────────────
const C = {
  bg:    '#0a0e1a', bg2: '#111827', bg3: '#1a2235',
  border:'rgba(255,255,255,0.08)',
  accent:'#00d4aa', blue:'#3b82f6',
  red:   '#ef4444', green:'#22c55e', amber:'#f59e0b',
  text:  '#f1f5f9', muted:'#64748b',
};

// ── SIGNAL ENGINE ──────────────────────────────────────────
function calcMA(data, window) {
  if (!data.length) return 0;
  const slice = data.slice(-window);
  return slice.reduce((a, b) => a + b, 0) / slice.length;
}

function calcVolatility(data) {
  if (data.length < 5) return 0;
  const slice = data.slice(-20);
  const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
  const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / slice.length;
  return (Math.sqrt(variance) / mean) * 100;
}

function detectTrend(data) {
  if (data.length < 5) return 'sideways';
  const recent = data.slice(-8);
  const f = recent.slice(0, 4).reduce((a, b) => a + b, 0) / 4;
  const l = recent.slice(-4).reduce((a, b) => a + b, 0) / 4;
  const pct = ((l - f) / f) * 100;
  if (pct > 0.15) return 'uptrend';
  if (pct < -0.15) return 'downtrend';
  return 'sideways';
}

function generateSignal(price, history) {
  if (history.length < 5) return { type: 'WAIT', confidence: 15, reason: 'Gathering data...' };
  const ma20 = calcMA(history, 20);
  const vol  = calcVolatility(history);
  const trend = detectTrend(history);
  const priceDiff = ((price - ma20) / ma20) * 100;
  const recent3 = history.slice(-3);
  const momentum = ((recent3[recent3.length-1] - recent3[0]) / recent3[0]) * 100;
  const dipScore   = -priceDiff;
  const spikeScore = priceDiff;
  const isBelowMA = price < ma20;
  const isAboveMA = price > ma20;
  const isLowVol  = vol < 0.3;
  const isHighVol = vol > 0.8;

  let type, confidence, reason;

  if (isBelowMA && dipScore > 0.4 && isLowVol && momentum <= 0) {
    type = 'STRONG BUY'; confidence = Math.min(93, 60 + dipScore * 15 + 10);
    reason = 'Deep dip + low volatility + below MA(20)';
  } else if (isBelowMA && dipScore > 0.15 && trend !== 'downtrend') {
    type = 'BUY'; confidence = Math.min(80, 45 + dipScore * 20);
    reason = 'Price below MA(20) — accumulation zone';
  } else if (isLowVol && trend === 'sideways' && isBelowMA) {
    type = 'BUY'; confidence = 52;
    reason = 'Low volatility accumulation zone';
  } else if (isAboveMA && spikeScore > 0.5 && isHighVol) {
    type = 'STRONG SELL'; confidence = Math.min(91, 60 + spikeScore * 12);
    reason = 'Overbought spike — high volatility exit';
  } else if (isAboveMA && spikeScore > 0.2 && momentum > 0.05) {
    type = 'SELL'; confidence = Math.min(78, 45 + spikeScore * 15);
    reason = 'Above MA(20) + upward momentum — take profit';
  } else if (isHighVol && trend === 'uptrend' && isAboveMA) {
    type = 'SELL'; confidence = 58;
    reason = 'High volatility on uptrend — partial exit';
  } else {
    type = 'WAIT'; confidence = isLowVol ? 55 : 35;
    reason = trend === 'sideways' ? 'Sideways market — hold position'
           : trend === 'uptrend'  ? 'Uptrend — wait for better entry'
           : 'Downtrend — avoid buying';
  }
  return {
    type, confidence: Math.round(confidence), reason,
    ma20, priceDiff: priceDiff.toFixed(3),
    momentum: momentum.toFixed(3),
    vol: isLowVol ? 'Low' : isHighVol ? 'High' : 'Medium',
    trend, dipScore: dipScore.toFixed(3), spikeScore: spikeScore.toFixed(3),
  };
}

// ── SIMULATED PRICE ────────────────────────────────────────
let _lastPrice = 278.5;
function simPrice() {
  const drift = (Math.random() - 0.48) * 0.35;
  const noise = (Math.random() - 0.5)  * 0.15;
  _lastPrice = Math.max(268, Math.min(295, _lastPrice + drift + noise));
  return _lastPrice;
}

// ── SIMPLE STORAGE (in-memory for Snack) ──────────────────
let _trades = [];
let _alerts = [];

// ── TABS ──────────────────────────────────────────────────
const TABS = ['Market', 'Signals', 'Trade', 'Portfolio', 'Alerts'];

// ══════════════════════════════════════════════════════════
export default function App() {
  const [tab, setTab]           = useState('Market');
  const [history, setHistory]   = useState([]);
  const [price, setPrice]       = useState(null);
  const [prevPrice, setPrev]    = useState(null);
  const [signal, setSignal]     = useState({ type:'WAIT', confidence:0, reason:'Starting...' });
  const [sigHistory, setSigHist]= useState([]);
  const [trades, setTrades]     = useState([]);
  const [alerts, setAlerts]     = useState([]);
  const [tradeType, setTType]   = useState('BUY');
  const [pkrVal, setPkr]        = useState('');
  const [rateVal, setRate]      = useState('');
  const lastSigRef              = useRef('');

  // ── Market refresh every 12s ─────────────────────────────
  useEffect(() => {
    const run = () => {
      const p = simPrice();
      setHistory(prev => {
        const next = [...prev, p].slice(-50);
        const sig = generateSignal(p, next);
        setSignal(sig);
        setPrev(price);
        setPrice(p);
        if (sig.type !== lastSigRef.current && sig.type !== 'WAIT') {
          lastSigRef.current = sig.type;
          const now = new Date().toLocaleTimeString();
          const msg = `[${now}] ${sig.type} — ${sig.reason} @ ₨${p.toFixed(2)}`;
          setSigHist(sh => [{ ...sig, time: now, px: p.toFixed(2) }, ...sh].slice(0, 15));
          setAlerts(al => [msg, ...al].slice(0, 40));
        }
        return next;
      });
    };
    run();
    const id = setInterval(run, 12000);
    return () => clearInterval(id);
  }, []);

  const addTrade = useCallback(() => {
    const pkr  = parseFloat(pkrVal);
    const rate = rateVal ? parseFloat(rateVal) : price;
    if (!pkr || !rate) { Alert.alert('Error', 'PKR amount aur rate dono bharo'); return; }
    const usdt = pkr / rate;
    const now  = new Date();
    const t = {
      id: Date.now().toString(), type: tradeType,
      pkr, rate, usdt,
      date: now.toLocaleDateString(),
      time: now.toLocaleTimeString(),
      market: detectTrend(history),
      signal: signal.type,
    };
    setTrades(prev => [...prev, t]);
    setPkr(''); setRate('');
    Alert.alert('✅ Trade Recorded!', `${tradeType}: ${usdt.toFixed(4)} USDT @ ₨${rate.toFixed(2)}`);
    setTab('Portfolio');
  }, [pkrVal, rateVal, price, tradeType, history, signal]);

  const deleteTrade = useCallback((id) => {
    Alert.alert('Delete?', 'Ye trade remove ho jayegi', [
      { text: 'Cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => setTrades(p => p.filter(t => t.id !== id)) },
    ]);
  }, []);

  const ma20   = calcMA(history, 20);
  const vol    = calcVolatility(history);
  const trend  = detectTrend(history);
  const change = prevPrice && price ? ((price - prevPrice) / prevPrice * 100) : 0;
  const h24    = history.length > 1 ? Math.max(...history) : price ?? 0;
  const l24    = history.length > 1 ? Math.min(...history) : price ?? 0;
  const sigColor = signal.type.includes('BUY')  ? C.green
                 : signal.type.includes('SELL') ? C.red : C.amber;

  // portfolio calc
  const buys = trades.filter(t => t.type === 'BUY');
  const sells= trades.filter(t => t.type === 'SELL');
  const totalUsdt    = buys.reduce((a,t)=>a+t.usdt,0) - sells.reduce((a,t)=>a+t.usdt,0);
  const totalInvested= buys.reduce((a,t)=>a+t.pkr, 0);
  const totalOut     = sells.reduce((a,t)=>a+t.pkr, 0);
  const curVal       = price ? totalUsdt * price : 0;
  const pnl          = curVal - (totalInvested - totalOut);
  const roi          = totalInvested > 0 ? (pnl / totalInvested * 100) : 0;
  const avgBuy       = buys.length > 0
    ? buys.reduce((a,t)=>a+t.rate*t.usdt,0) / buys.reduce((a,t)=>a+t.usdt,0) : 0;

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />

      {/* HEADER */}
      <View style={s.header}>
        <View style={s.hLeft}>
          <View style={s.liveDot} />
          <Text style={s.hTitle}>asadsindhi1</Text>
          <View style={s.liveBadge}><Text style={s.liveTxt}>LIVE</Text></View>
        </View>
        <Text style={s.muted}>{price ? `₨ ${price.toFixed(2)}` : 'Loading...'}</Text>
      </View>

      {/* TABS */}
      <View style={s.tabs}>
        {TABS.map(t => (
          <TouchableOpacity key={t} style={[s.tab, tab===t && s.tabActive]} onPress={()=>setTab(t)}>
            <Text style={[s.tabTxt, tab===t && s.tabTxtA]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={s.body} contentContainerStyle={{paddingBottom:40}} keyboardShouldPersistTaps="handled">

        {/* ══ MARKET TAB ══ */}
        {tab==='Market' && (
          <View style={s.p}>
            {/* Price Hero */}
            <View style={s.hero}>
              <Text style={s.heroLabel}>USDT / PKR Live Rate</Text>
              {price ? <>
                <Text style={s.heroPrice}>₨ {price.toFixed(2)}</Text>
                <View style={[s.chgBadge,{backgroundColor:change>=0?'rgba(34,197,94,0.15)':'rgba(239,68,68,0.15)'}]}>
                  <Text style={{color:change>=0?C.green:C.red,fontWeight:'700',fontSize:12}}>
                    {change>=0?'▲ +':'▼ '}{Math.abs(change).toFixed(4)}%
                  </Text>
                </View>
              </> : <ActivityIndicator color={C.accent} style={{marginTop:12}}/>}
            </View>

            {/* Stats grid */}
            <View style={s.grid2}>
              {[
                {l:'24H HIGH', v:`₨${h24.toFixed(2)}`, c:C.green},
                {l:'24H LOW',  v:`₨${l24.toFixed(2)}`, c:C.red},
                {l:'MA (20)',  v:`₨${ma20.toFixed(2)}`, c:C.text},
                {l:'TREND',    v:trend.toUpperCase(), c:trend==='uptrend'?C.green:trend==='downtrend'?C.red:C.amber},
              ].map(x=>(
                <View key={x.l} style={s.miniCard}>
                  <Text style={s.miniL}>{x.l}</Text>
                  <Text style={[s.miniV,{color:x.c}]}>{x.v}</Text>
                </View>
              ))}
            </View>

            {/* Signal preview */}
            <View style={[s.sigCard,{backgroundColor:sigColor+'15',borderColor:sigColor+'44'}]}>
              <View>
                <Text style={[s.sigLabel,{color:sigColor}]}>{signal.type}</Text>
                <Text style={s.muted}>{signal.reason}</Text>
              </View>
              <View style={{alignItems:'flex-end'}}>
                <Text style={s.muted}>Confidence</Text>
                <View style={s.confTrack}>
                  <View style={[s.confFill,{width:`${signal.confidence}%`,backgroundColor:sigColor}]}/>
                </View>
                <Text style={[s.bold,{color:sigColor}]}>{signal.confidence}%</Text>
              </View>
            </View>

            {/* Zones */}
            <Text style={s.secTitle}>Smart Trade Zones</Text>
            <View style={s.zoneCard}>
              <View style={s.zoneHdr}>
                <Text style={[s.bold,{color:C.green}]}>▼ BUY ZONE</Text>
                <View style={[s.riskPill,{backgroundColor:'rgba(34,197,94,0.15)',borderColor:'rgba(34,197,94,0.4)'}]}>
                  <Text style={{color:C.green,fontSize:10,fontWeight:'700'}}>LOW RISK</Text>
                </View>
              </View>
              <Row k="Target entry"    v={`₨ ${(ma20*0.996).toFixed(2)}`}/>
              <Row k="Below MA(20)"    v="0.40%"/>
              <Row k="Action"          v="Wait for dip → BUY"/>
            </View>
            <View style={s.zoneCard}>
              <View style={s.zoneHdr}>
                <Text style={[s.bold,{color:C.red}]}>▲ SELL ZONE</Text>
                <View style={[s.riskPill,{backgroundColor:'rgba(245,158,11,0.15)',borderColor:'rgba(245,158,11,0.4)'}]}>
                  <Text style={{color:C.amber,fontSize:10,fontWeight:'700'}}>MED RISK</Text>
                </View>
              </View>
              <Row k="Target exit"     v={`₨ ${(ma20*1.006).toFixed(2)}`}/>
              <Row k="Above MA(20)"    v="0.60%"/>
              <Row k="Action"          v="SELL above this zone"/>
            </View>
          </View>
        )}

        {/* ══ SIGNALS TAB ══ */}
        {tab==='Signals' && (
          <View style={s.p}>
            <View style={[s.sigCard,{backgroundColor:sigColor+'15',borderColor:sigColor+'44'}]}>
              <View>
                <Text style={[s.sigLabel,{color:sigColor,fontSize:28}]}>{signal.type}</Text>
                <Text style={s.muted}>{signal.reason}</Text>
              </View>
              <View style={{alignItems:'flex-end'}}>
                <Text style={s.muted}>Confidence</Text>
                <View style={s.confTrack}>
                  <View style={[s.confFill,{width:`${signal.confidence}%`,backgroundColor:sigColor}]}/>
                </View>
                <Text style={[s.bold,{color:sigColor,fontSize:18}]}>{signal.confidence}%</Text>
              </View>
            </View>

            <Text style={s.secTitle}>Analysis</Text>
            <View style={s.card}>
              <Row k="Price vs MA(20)" v={`${parseFloat(signal.priceDiff||0)>0?'+':''}${signal.priceDiff||'—'}%`}/>
              <Row k="Momentum"        v={signal.momentum ? `${parseFloat(signal.momentum)>0?'▲ +':'▼ '}${signal.momentum}%` : '—'}/>
              <Row k="Volatility"      v={signal.vol||'—'}/>
              <Row k="Trend"           v={signal.trend ? signal.trend.charAt(0).toUpperCase()+signal.trend.slice(1) : '—'}/>
              <Row k="Dip Score"       v={signal.dipScore ? `${signal.dipScore}%` : '—'}/>
              <Row k="Spike Score"     v={signal.spikeScore ? `${signal.spikeScore}%` : '—'}/>
            </View>

            <Text style={s.secTitle}>Signal History</Text>
            {sigHistory.length===0
              ? <Text style={s.empty}>Koi signal nahi aya abhi tak...</Text>
              : sigHistory.map((sg,i)=>(
                <View key={i} style={s.alertItem}>
                  <View style={[s.dot,{backgroundColor:sg.type.includes('BUY')?C.green:sg.type.includes('SELL')?C.red:C.amber}]}/>
                  <View style={{flex:1}}>
                    <Text style={s.bold}>{sg.type} — {sg.reason}</Text>
                    <Text style={s.muted}>{sg.time} · ₨{sg.px} · {sg.confidence}%</Text>
                  </View>
                </View>
              ))
            }
          </View>
        )}

        {/* ══ TRADE TAB ══ */}
        {tab==='Trade' && (
          <View style={s.p}>
            <View style={s.card}>
              <Text style={s.secTitle}>Trade Type</Text>
              <View style={s.typeRow}>
                <TouchableOpacity
                  style={[s.typeBtn, tradeType==='BUY' && {backgroundColor:'rgba(34,197,94,0.15)',borderColor:C.green}]}
                  onPress={()=>setTType('BUY')}>
                  <Text style={[s.typeTxt, tradeType==='BUY' && {color:C.green}]}>BUY</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[s.typeBtn, tradeType==='SELL' && {backgroundColor:'rgba(239,68,68,0.15)',borderColor:C.red}]}
                  onPress={()=>setTType('SELL')}>
                  <Text style={[s.typeTxt, tradeType==='SELL' && {color:C.red}]}>SELL</Text>
                </TouchableOpacity>
              </View>

              <Text style={[s.secTitle,{marginTop:12}]}>PKR Amount</Text>
              <TextInput style={s.input} value={pkrVal} onChangeText={setPkr}
                placeholder="e.g. 10000" placeholderTextColor={C.muted} keyboardType="numeric"/>

              <Text style={[s.secTitle,{marginTop:12}]}>Rate (PKR per USDT)</Text>
              <TextInput style={s.input} value={rateVal} onChangeText={setRate}
                placeholder={price ? `Auto: ₨ ${price.toFixed(2)}` : 'Enter rate'}
                placeholderTextColor={C.muted} keyboardType="numeric"/>

              {pkrVal && (parseFloat(rateVal)||price) ? (
                <View style={[s.card,{backgroundColor:C.bg3,marginTop:12}]}>
                  <Row k="USDT Amount" v={`${(parseFloat(pkrVal)/(parseFloat(rateVal)||price)).toFixed(6)} USDT`}/>
                  <Row k="Rate"        v={`₨ ${(parseFloat(rateVal)||price||0).toFixed(2)}`}/>
                  <Row k="Market"      v={trend.charAt(0).toUpperCase()+trend.slice(1)}/>
                  <Row k="Signal"      v={signal.type}/>
                </View>
              ) : null}

              <TouchableOpacity style={[s.btnPrimary,{marginTop:16}]} onPress={addTrade}>
                <Text style={s.btnTxt}>+ Trade Record Karo</Text>
              </TouchableOpacity>
            </View>

            <Text style={s.secTitle}>Trade History</Text>
            {trades.length===0
              ? <Text style={s.empty}>Koi trade nahi abhi tak. Upar se record karo.</Text>
              : [...trades].reverse().map(t => {
                  const cv = price ? t.usdt * price : null;
                  const pl = cv && t.type==='BUY' ? cv - t.pkr : null;
                  const ri = pl !== null && t.pkr > 0 ? (pl/t.pkr*100).toFixed(2) : null;
                  return (
                    <View key={t.id} style={s.tradeItem}>
                      <View style={s.tradeHdr}>
                        <View style={[s.tradeBadge,{backgroundColor:t.type==='BUY'?'rgba(34,197,94,0.15)':'rgba(239,68,68,0.15)'}]}>
                          <Text style={{color:t.type==='BUY'?C.green:C.red,fontWeight:'800',fontSize:11}}>{t.type}</Text>
                        </View>
                        <View style={{flexDirection:'row',alignItems:'center',gap:8}}>
                          <Text style={s.muted}>{t.date}</Text>
                          <TouchableOpacity onPress={()=>deleteTrade(t.id)}>
                            <Text style={{color:C.red,fontSize:18,paddingHorizontal:6}}>×</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                      <View style={s.tradeDetails}>
                        <View><Text style={s.tdL}>PKR</Text><Text style={s.bold}>₨{t.pkr.toLocaleString()}</Text></View>
                        <View><Text style={s.tdL}>USDT</Text><Text style={s.bold}>{t.usdt.toFixed(4)}</Text></View>
                        <View><Text style={s.tdL}>Rate</Text><Text style={s.bold}>{t.rate.toFixed(1)}</Text></View>
                      </View>
                      {pl !== null && (
                        <Text style={[s.bold,{color:pl>=0?C.green:C.red,fontSize:11,marginTop:4}]}>
                          Live P&L: {pl>=0?'+':''}₨{Math.round(pl).toLocaleString()} ({ri}% ROI)
                        </Text>
                      )}
                      <Text style={[s.muted,{fontSize:10,marginTop:2}]}>Signal: {t.signal} · {t.market}</Text>
                    </View>
                  );
                })
            }
          </View>
        )}

        {/* ══ PORTFOLIO TAB ══ */}
        {tab==='Portfolio' && (
          <View style={s.p}>
            <View style={[s.card,{alignItems:'center',paddingVertical:24}]}>
              <Text style={s.muted}>Total Portfolio Value</Text>
              <Text style={[s.heroPrice,{marginVertical:8}]}>₨ {Math.round(curVal).toLocaleString()}</Text>
              <Text style={[s.bold,{color:pnl>=0?C.green:C.red,fontSize:15}]}>
                P&L: {pnl>=0?'+':''}₨{Math.round(pnl).toLocaleString()} ({roi.toFixed(2)}%)
              </Text>
            </View>
            <View style={s.grid2}>
              {[
                {l:'USDT Balance',  v:`${totalUsdt.toFixed(4)} USDT`},
                {l:'PKR Invested',  v:`₨${Math.round(totalInvested).toLocaleString()}`},
                {l:'ROI %',         v:`${roi.toFixed(2)}%`,  c:roi>=0?C.green:C.red},
                {l:'Total Trades',  v:trades.length.toString()},
                {l:'Avg Buy Rate',  v:avgBuy>0?`₨${avgBuy.toFixed(2)}`:'—'},
                {l:'Live Rate',     v:price?`₨${price.toFixed(2)}`:'—'},
              ].map(x=>(
                <View key={x.l} style={s.miniCard}>
                  <Text style={s.miniL}>{x.l}</Text>
                  <Text style={[s.miniV,x.c?{color:x.c}:{}]}>{x.v}</Text>
                </View>
              ))}
            </View>
            {trades.length > 0 && (
              <>
                <Text style={s.secTitle}>Best / Worst Trades</Text>
                <View style={s.card}>
                  {(() => {
                    const rs = trades.map(t => {
                      const cv2 = price ? t.usdt * price : t.pkr;
                      return { lbl:`${t.type} ₨${t.pkr.toLocaleString()} @ ${t.rate.toFixed(1)}`, roi: t.type==='BUY'?(cv2-t.pkr)/t.pkr*100:0 };
                    });
                    const best  = rs.reduce((a,b)=>b.roi>a.roi?b:a,rs[0]);
                    const worst = rs.reduce((a,b)=>b.roi<a.roi?b:a,rs[0]);
                    return <>
                      <Row k="Best ROI"  v={`+${best.roi.toFixed(2)}% — ${best.lbl}`}  vc={C.green}/>
                      <Row k="Worst ROI" v={`${worst.roi.toFixed(2)}% — ${worst.lbl}`} vc={C.red}/>
                    </>;
                  })()}
                </View>
              </>
            )}
          </View>
        )}

        {/* ══ ALERTS TAB ══ */}
        {tab==='Alerts' && (
          <View style={s.p}>
            <Text style={s.secTitle}>Alert Log ({alerts.length})</Text>
            {alerts.length===0
              ? <Text style={s.empty}>Koi alert nahi. Signal change hone par yahan ayenge.</Text>
              : alerts.map((a,i)=>(
                <View key={i} style={s.alertItem}>
                  <View style={[s.dot,{backgroundColor:a.includes('BUY')?C.green:a.includes('SELL')?C.red:C.amber}]}/>
                  <Text style={[s.muted,{flex:1,fontSize:12}]}>{a}</Text>
                </View>
              ))
            }
          </View>
        )}

      </ScrollView>
    </View>
  );
}

// ── HELPER COMPONENTS ─────────────────────────────────────
function Row({ k, v, vc }) {
  return (
    <View style={s.row}>
      <Text style={s.muted}>{k}</Text>
      <Text style={[s.bold, vc ? { color: vc } : {}]}>{v}</Text>
    </View>
  );
}

// ── STYLES ────────────────────────────────────────────────
const s = StyleSheet.create({
  root:       { flex:1, backgroundColor:C.bg },
  body:       { flex:1 },
  p:          { padding:12 },
  header:     { flexDirection:'row', justifyContent:'space-between', alignItems:'center',
                padding:12, backgroundColor:C.bg2,
                borderBottomWidth:1, borderBottomColor:C.border, paddingTop:40 },
  hLeft:      { flexDirection:'row', alignItems:'center', gap:8 },
  hTitle:     { fontSize:16, fontWeight:'700', color:C.text, letterSpacing:0.5 },
  liveDot:    { width:8, height:8, borderRadius:4, backgroundColor:C.accent },
  liveBadge:  { backgroundColor:'rgba(0,212,170,0.15)', borderRadius:20,
                paddingHorizontal:8, paddingVertical:2,
                borderWidth:1, borderColor:'rgba(0,212,170,0.3)' },
  liveTxt:    { color:C.accent, fontSize:9, fontWeight:'700', letterSpacing:0.5 },
  tabs:       { flexDirection:'row', backgroundColor:C.bg2,
                borderBottomWidth:1, borderBottomColor:C.border },
  tab:        { flex:1, paddingVertical:10, alignItems:'center',
                borderBottomWidth:2, borderBottomColor:'transparent' },
  tabActive:  { borderBottomColor:C.accent },
  tabTxt:     { fontSize:10, fontWeight:'500', color:C.muted },
  tabTxtA:    { color:C.accent },
  card:       { backgroundColor:C.bg2, borderRadius:10, borderWidth:1,
                borderColor:C.border, padding:14, marginBottom:12 },
  miniCard:   { backgroundColor:C.bg2, borderRadius:8, borderWidth:1,
                borderColor:C.border, padding:12, flex:1, minWidth:'45%' },
  grid2:      { flexDirection:'row', flexWrap:'wrap', gap:8, marginBottom:12 },
  hero:       { backgroundColor:C.bg2, borderRadius:10, borderWidth:1,
                borderColor:C.border, padding:16, marginBottom:12, alignItems:'flex-start' },
  heroLabel:  { fontSize:11, color:C.muted, textTransform:'uppercase', letterSpacing:0.8 },
  heroPrice:  { fontSize:32, fontWeight:'800', color:C.text, letterSpacing:-0.5, marginTop:4 },
  chgBadge:   { borderRadius:20, paddingHorizontal:10, paddingVertical:4, marginTop:8 },
  miniL:      { fontSize:10, color:C.muted, textTransform:'uppercase', letterSpacing:0.5, marginBottom:4 },
  miniV:      { fontSize:14, fontWeight:'700', color:C.text },
  sigCard:    { borderRadius:10, borderWidth:1, padding:14,
                flexDirection:'row', justifyContent:'space-between',
                alignItems:'center', marginBottom:12 },
  sigLabel:   { fontSize:22, fontWeight:'800', letterSpacing:1 },
  confTrack:  { width:80, height:6, backgroundColor:C.border,
                borderRadius:3, overflow:'hidden', marginVertical:4 },
  confFill:   { height:'100%', borderRadius:3 },
  secTitle:   { fontSize:11, fontWeight:'700', color:C.muted,
                textTransform:'uppercase', letterSpacing:0.8, marginVertical:8 },
  zoneCard:   { backgroundColor:C.bg2, borderRadius:10, borderWidth:1,
                borderColor:C.border, padding:12, marginBottom:8 },
  zoneHdr:    { flexDirection:'row', justifyContent:'space-between',
                alignItems:'center', marginBottom:8 },
  riskPill:   { borderRadius:20, borderWidth:1, paddingHorizontal:8, paddingVertical:2 },
  row:        { flexDirection:'row', justifyContent:'space-between', paddingVertical:3 },
  bold:       { color:C.text, fontWeight:'600', fontSize:13 },
  muted:      { color:C.muted, fontSize:12 },
  empty:      { color:C.muted, textAlign:'center', paddingVertical:32, fontSize:13 },
  input:      { backgroundColor:C.bg3, borderRadius:8, borderWidth:1,
                borderColor:C.border, padding:12, fontSize:14,
                color:C.text, marginBottom:4 },
  typeRow:    { flexDirection:'row', gap:8 },
  typeBtn:    { flex:1, padding:12, borderRadius:8, borderWidth:1,
                borderColor:C.border, backgroundColor:C.bg3, alignItems:'center' },
  typeTxt:    { fontWeight:'700', fontSize:13, color:C.muted },
  btnPrimary: { backgroundColor:C.accent, borderRadius:8, padding:14, alignItems:'center' },
  btnTxt:     { color:'#0a0e1a', fontWeight:'800', fontSize:14 },
  tradeItem:  { backgroundColor:C.bg2, borderRadius:8, borderWidth:1,
                borderColor:C.border, padding:12, marginBottom:8 },
  tradeHdr:   { flexDirection:'row', justifyContent:'space-between',
                alignItems:'center', marginBottom:8 },
  tradeBadge: { borderRadius:20, paddingHorizontal:10, paddingVertical:3 },
  tradeDetails:{ flexDirection:'row', justifyContent:'space-between', marginTop:4 },
  tdL:        { fontSize:9, color:C.muted, textTransform:'uppercase' },
  alertItem:  { flexDirection:'row', alignItems:'flex-start', gap:10, backgroundColor:C.bg2,
                borderRadius:8, borderWidth:1, borderColor:C.border, padding:12, marginBottom:8 },
  dot:        { width:8, height:8, borderRadius:4, marginTop:4, flexShrink:0 },
});